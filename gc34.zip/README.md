# COMP509-CNFSolver

A program for deciding the CNF satisfiability.

For solving the einstein's puzzle, input: 
```
./CNF -i einstein.cnf -s
```

For testing the performance, input: 
```
./CNF -g N
```